package cl.duoc.miprimeraapi.repository;

import cl.duoc.miprimeraapi.model.Sucursales;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SucursalesRepository extends JpaRepository<Sucursales, Long> {
}
